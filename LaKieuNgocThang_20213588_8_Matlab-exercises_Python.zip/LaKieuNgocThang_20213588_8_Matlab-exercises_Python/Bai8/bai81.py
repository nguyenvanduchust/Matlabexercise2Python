import numpy as np
import matplotlib.pyplot as plt
from scipy.fftpack import fft, ifft
from scipy.signal import convolve

def ofdm_modulator(data, NFFT, G):
    """
    Modulates data into an OFDM signal.

    Parameters:
    - data: Input data symbols
    - NFFT: FFT size
    - G: Guard interval size

    Returns:
    - OFDM modulated signal
    """
    chnr = len(data)
    x = np.concatenate([data, np.zeros(NFFT - chnr)])
    a = ifft(x)
    y = np.concatenate([a[-G:], a])
    return y

def ofdm_demodulator(data, chnr, NFFT, G):
    """
    Demodulates an OFDM signal back to data symbols.

    Parameters:
    - data: OFDM modulated signal
    - chnr: Number of data symbols
    - NFFT: FFT size
    - G: Guard interval size

    Returns:
    - Demodulated data symbols
    """
    x_remove_guard_interval = data[G:NFFT + G]
    x = fft(x_remove_guard_interval)
    y = x[:chnr]
    return y

def qam_modulator(data, M):
    """
    Modulates data symbols using QAM.

    Parameters:
    - data: Input data symbols
    - M: QAM modulation order

    Returns:
    - QAM modulated symbols
    """
    return np.sqrt(1 / 10) * np.exp(1j * (np.pi / M) * (2 * data + 1))

def qam_demodulator(symbols, M):
    """
    Demodulates QAM symbols back to data symbols.

    Parameters:
    - symbols: QAM modulated symbols
    - M: QAM modulation order

    Returns:
    - Demodulated data symbols
    """
    demod_data = (np.angle(symbols) / (np.pi / M) - 1) / 2
    return np.round(demod_data).astype(int) % M

def symerr(a, b):
    """
    Calculates symbol error rate (SER) and number of errors.

    Parameters:
    - a: Original data symbols
    - b: Decoded data symbols

    Returns:
    - Number of errors, Symbol error rate (SER)
    """
    num_errors = np.sum(a != b)
    error_rate = num_errors / len(a)
    return num_errors, error_rate

def awgn(s, snr_dB):
    """
    Adds Additive White Gaussian Noise (AWGN) to the signal.

    Parameters:
    - s: Input signal
    - snr_dB: Signal-to-Noise Ratio (SNR) in dB

    Returns:
    - Signal with AWGN added
    """
    snr_linear = 10**(snr_dB / 10)
    power_signal = np.mean(np.abs(s)**2)
    noise_variance = power_signal / snr_linear
    noise = np.sqrt(noise_variance / 2) * (np.random.randn(*s.shape) + 1j * np.random.randn(*s.shape))
    return s + noise

# Parameters
NFFT = 64  # FFT size
G = 9  # Guard interval size
M_ary = 16  # QAM modulation order
rho = np.array([100, 0.6095, 0.4945, 0.3940, 0.2371, 0.19, 0.1159, 0.0699, 0.0462])  # Channel tap gains
N_P = len(rho)
h = np.sqrt(rho)
H = fft(np.concatenate([h, np.zeros(NFFT - N_P)]))
NofOFDMSymbol = 100
length_data = NofOFDMSymbol * NFFT

# Generate random source data
source_data = np.random.randint(0, M_ary, length_data)

# QAM modulation
symbols = source_data
qam_symbols = qam_modulator(symbols, M_ary)

# Arrange QAM symbols into OFDM data pattern
data_pattern = qam_symbols.reshape((NofOFDMSymbol, NFFT))

# Calculate Symbol Error Rate (SER) over SNR range
ser = []
snr_min = 0
snr_max = 25
step = 1
snr_range = np.arange(snr_min, snr_max + 1, step)

for snr in snr_range:
    # Effective SNR for each symbol due to OFDM modulation
    snt = snr - 10 * np.log10((NFFT + G) / NFFT)
    rs_frame = []

    # Generate OFDM signals for each symbol, add channel effects and noise
    for i in range(NofOFDMSymbol):
        ofdm_signal = ofdm_modulator(data_pattern[i, :], NFFT, G)
        rs = convolve(ofdm_signal, h)[:len(ofdm_signal)]
        rs = awgn(rs, snr)
        rs_frame.append(rs)

    rs_frame = np.array(rs_frame)

    # Demodulate received symbols
    data_symbol = []
    for i in range(NofOFDMSymbol):
        if N_P > G + 1 and i > 0:
            previous_symbol = rs_frame[i - 1, :]
            ISI_term = previous_symbol[NFFT + 2 * G + 1:NFFT + G + N_P - 1]
            ISI = np.concatenate([ISI_term, np.zeros(len(previous_symbol) - len(ISI_term))])
            rs_i = rs_frame[i, :] + ISI
        else:
            rs_i = rs_frame[i, :]

        demodulated_signal_i = ofdm_demodulator(rs_i, NFFT, NFFT, G)
        d = demodulated_signal_i / H
        demodulated_symbol_i = qam_demodulator(d, M_ary)
        data_symbol.extend(demodulated_symbol_i)

    data_symbol = np.array(data_symbol)

    # Calculate Symbol Error Rate (SER)
    num_errors, error_rate = symerr(symbols, data_symbol)
    ser.append(error_rate)

# Plot Symbol Error Rate (SER) vs SNR
plt.semilogy(snr_range, ser, 'bo')
plt.ylabel('SER')
plt.xlabel('SNR in dB')
plt.title('Symbol Error Rate (SER) vs SNR for OFDM')
plt.grid(True)
plt.savefig('SER_vs_SNR_OFDM.png')  # Save the plot as an image file
plt.show()
