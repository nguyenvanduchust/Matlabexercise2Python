import numpy as np
import matplotlib.pyplot as plt

def cha(SNR_db, S, x):
    """
    Calculate the bit error probability for a given SNR.
    
    Parameters:
    SNR_db (float): Signal-to-noise ratio in dB.
    S (array): QPSK modulated signal.
    x (array): Original bit sequence.
    
    Returns:
    bit_errors (int): Number of bit errors detected.
    """
    Es = np.var(S)  # Symbol energy
    Eb = Es / 2  # Bit energy
    N_0 = Eb / 10**(SNR_db / 10)  # Noise power spectral density
    N = np.sqrt(N_0 / 2) * (np.random.randn(*S.shape) + 1j * np.random.randn(*S.shape))  # Noise
    R = S + N  # Received signal with noise
    
    detected_bits = np.zeros_like(x)
    
    for i in range(len(R)):
        if np.angle(R[i]) < np.pi / 4 and np.angle(R[i]) >= -np.pi / 4:
            detected_bits[2 * i] = 0
            detected_bits[2 * i + 1] = 0
        elif np.angle(R[i]) < 3 * np.pi / 4 and np.angle(R[i]) >= np.pi / 4:
            detected_bits[2 * i] = 0
            detected_bits[2 * i + 1] = 1
        elif np.angle(R[i]) < -3 * np.pi / 4 or np.angle(R[i]) >= 3 * np.pi / 4:
            detected_bits[2 * i] = 1
            detected_bits[2 * i + 1] = 1
        else:
            detected_bits[2 * i] = 1
            detected_bits[2 * i + 1] = 0
    
    bit_errors = np.sum(x != detected_bits)  # Number of bit errors
    
    return bit_errors

# Load data from the .npz file
data = np.load('ex5p1_Res.npz')
S = data['S']
x = data['x']

# SNR values
SNR_db = np.arange(0, 10, 2)

# Calculate bit error probability
c = np.zeros(len(SNR_db))
for i in range(len(SNR_db)):
    c[i] = cha(SNR_db[i], S, x)

BEP = c / len(x)  # Bit error probability

# Plotting the bit error probability
plt.semilogy(SNR_db, BEP, '--')
plt.title('The bit error probability')
plt.xlabel('SNR in dB')
plt.ylabel(r'$P_b$')
plt.legend([r'$P_b$'])
plt.grid(True)

# Save the plot
plt.savefig('bit_error_probability.png')

# Show the plot
plt.show()

# Save the results in a .npz file
np.savez('ex6p1_Res.npz', c=c, BEP=BEP)
