import numpy as np
import matplotlib.pyplot as plt

# Modulation index for QPSK
b = 1 / 2

# Array of Signal-to-Noise Ratio (SNR) values in dB
SNR_db = np.arange(0, 31, 5)

# Calculate average SNR for a slow flat Rayleigh fading channel
Gamma_Average = 2 * b * 10**(SNR_db / 10)

# Theoretical Bit Error Probability (BEP) for QPSK over a fading channel
p_b = (1 - np.sqrt(Gamma_Average / (1 + Gamma_Average))) / 2

# Plot theoretical BEP versus SNR_db with red dashed line
plt.semilogy(SNR_db, p_b, 'r--', label='BEP of QPSK over a fading channel (Theory)')

# Load simulated BEP values from file
data = np.load('ex6p3_Res.npz')
BEP = data['BEP']

# Plot simulated BEP versus SNR_db as blue circles
plt.semilogy(SNR_db, BEP, 'bo', label='BEP of QPSK over a fading channel (Simulation)')

# Plot labels and title in English
plt.title('BEP of slow flat Rayleigh fading channel')
plt.xlabel(r'$\gamma_b$')
plt.ylabel(r'$P_b$')
plt.legend()
plt.grid(True)

# Save the plot as an image file
plt.savefig('BEP_vs_SNR_QPSK_Fading.png')

# Display the plot
plt.show()
