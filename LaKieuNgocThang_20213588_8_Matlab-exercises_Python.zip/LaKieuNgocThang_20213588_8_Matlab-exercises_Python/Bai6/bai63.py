import numpy as np
import matplotlib.pyplot as plt

# Function to generate the complex baseband signal
def g(c, f, th, t):
    """
    Generate a complex baseband signal using given parameters.

    Parameters:
    - c: Array of coefficients for cosine terms
    - f: Array of frequencies for cosine terms
    - th: Array of phase angles for cosine terms
    - t: Time array

    Returns:
    - Complex baseband signal y(t)
    """
    y = np.zeros_like(t, dtype=complex)
    for n in range(len(f)):
        y += c[n] * np.cos(2 * np.pi * f[n] * t + th[n])
    return y

# Function to simulate the receiver and calculate bit errors
def receiver(SNR_db, S_m, FS, x, S, g):
    """
    Simulate the receiver performance over a fading channel and calculate bit errors.

    Parameters:
    - SNR_db: Signal-to-noise ratio in dB
    - S_m: QPSK symbols
    - FS: Received signal
    - x: Transmitted bits
    - S: QPSK symbols (transmitted)
    - g: Fading coefficients

    Returns:
    - Number of bit errors detected
    """
    Es = np.var(S)
    Eb = Es / 2
    N_0 = Eb / 10**(SNR_db / 10)
    N = np.sqrt(N_0 / 2) * (np.random.randn(*FS.shape) + 1j * np.random.randn(*FS.shape))
    R = FS + N

    detected_bits = np.zeros_like(x)
    for i in range(0, len(R), 4):
        for j in range(4):
            distances = np.abs(R[i + j] - S_m * g[i + j])
            detected_symbol = S_m[np.argmin(distances)]
            detected_bits[2*i + 2*j:2*i + 2*j + 2] = [0, 0] if detected_symbol == np.exp(1j * np.pi / 4) else \
                                                      [0, 1] if detected_symbol == np.exp(1j * 3 * np.pi / 4) else \
                                                      [1, 1] if detected_symbol == np.exp(1j * 5 * np.pi / 4) else \
                                                      [1, 0]
    bit_errors = np.sum(x != detected_bits)
    return bit_errors

# Load simulation data
data = np.load('ex5p1_Res.npz')
S = data['S'][:20000]  # Use first 20000 symbols
x = data['x'][:40000]  # Use first 40000 bits

# Parameters for the fading channel simulation
f_m = 91
b = 1 / 2
N1 = 9
N2 = N1 + 1
f1 = f_m * np.sin(np.pi / 2 / N1 * (np.arange(1, N1 + 1) - 1 / 2))
c1 = np.sqrt(2 * b / N1) * np.ones_like(f1)
th1 = np.random.rand(len(f1)) * 2 * np.pi
f2 = f_m * np.sin(np.pi / 2 / N2 * (np.arange(1, N2 + 1) - 1 / 2))
c2 = np.sqrt(2 * b / N2) * np.ones_like(f2)
th2 = np.random.rand(len(f2)) * 2 * np.pi

# Sampling parameters
f_s = 270800
T_symb = 1 / f_s
t = np.arange(len(S)) * T_symb

# Generate fading components
g1 = g(c1, f1, th1, t)
g2 = g(c2, f2, th2, t)
g = g1 + 1j * g2
FS = g * S

# Define QPSK symbols and their phase angles
theta_m = np.array([np.pi / 4, 3 * np.pi / 4, 5 * np.pi / 4, 7 * np.pi / 4])
S_m = np.exp(1j * theta_m)

# Generate g * S_m for received symbols
gS_m = np.zeros_like(S, dtype=complex)
for i in range(len(S) // 4):
    gS_m[4 * i:4 * i + 4] = S_m * g[4 * i:4 * i + 4]

# SNR values to simulate
SNR_db = np.arange(0, 31, 5)

# Array to store bit errors
c = np.zeros(len(SNR_db))

# Simulate bit errors for each SNR value
for i in range(len(SNR_db)):
    c[i] = receiver(SNR_db[i], S_m, FS, x, S, g)

# Calculate bit error probability (BEP)
BEP = c / len(x)

# Save BEP to file
np.savez('ex6p3_Res.npz', BEP=BEP)

# Plot BEP versus SNR
plt.semilogy(SNR_db, BEP, '.--')
plt.title('The bit error probability of QPSK over a fading channel')
plt.xlabel('SNR in dB')
plt.ylabel(r'$P_b$')
plt.grid(True)

# Save the plot as a PNG file
plt.savefig('BEP_vs_SNR_QPSK_Fading_Channel.png')

plt.show()
