import numpy as np
import matplotlib.pyplot as plt
from scipy.special import erfc

# Theoretical bit error probability calculation
SNR_db = np.arange(0, 9)
SNR_db_simulation = np.arange(0, 9, 2)
SNR = 10**(SNR_db / 10)
gamma_b = SNR
p_b = erfc(np.sqrt(2 * gamma_b) / np.sqrt(2)) / 2

# Plot theoretical bit error probability
plt.semilogy(SNR_db, p_b, 'ro--', label='Theory')

# Load simulation results
data = np.load('ex6p1_Res.npz')
BEP = data['BEP']

# Plot simulation bit error probability
plt.semilogy(SNR_db_simulation, BEP, 'x--', label='Simulation')

# Plot settings
plt.title('The bit error probability')
plt.xlabel('SNR in dB')
plt.ylabel(r'$P_b$')
plt.legend()
plt.grid(True)

# Save the plot
plt.savefig('bit_error_probability_comparison.png')

# Show the plot
plt.show()
