import numpy as np

# Parameters
f_m = 91  # Maximum Doppler frequency
b = 1  # Some constant
N1 = 9  # Number of sinusoids for first set
N2 = 10  # Number of sinusoids for second set

# Calculate c1, f1, and th1
c1 = np.sqrt(2 * b / N1) * np.ones(N1)
f1 = f_m * np.sin(np.pi * (np.arange(1, N1 + 1) - 0.5) / (2 * N1))
th1 = 2 * np.pi * np.arange(1, N1 + 1) / (N1 + 1)

# Calculate c2, f2, and th2
c2 = np.sqrt(2 * b / N2) * np.ones(N2)
f2 = f_m * np.sin(np.pi * (np.arange(1, N2 + 1) - 0.5) / (2 * N2))
th2 = 2 * np.pi * np.arange(1, N2 + 1) / (N2 + 1)

# Save the results in a .npz file
np.savez('ex4p1_Res', f1=f1, f2=f2, c1=c1, c2=c2, th1=th1, th2=th2)
