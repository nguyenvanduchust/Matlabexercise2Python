import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import correlate

# Parameters
fm = 91  # Maximum Doppler frequency
b = 1  # Some constant
N1 = 9  # Number of sinusoids
fs = 1000  # Sampling frequency
t_sim = np.arange(10E3, 20E3) / fs  # Simulation time array

# Frequencies, amplitudes, and phases
f_1_n = fm * np.sin(np.pi * (np.arange(1, N1 + 1) - 1/2) / (2 * N1))
c_1_n = np.sqrt(2 * b / N1) * np.ones_like(f_1_n)
theta_1_n = 2 * np.pi * np.arange(1, N1 + 1) / (N1 + 1)

# Generate the deterministic process g1_t_tilde
g1_t_tilde = np.zeros_like(t_sim)
for k in range(len(f_1_n)):
    g1_t_tilde += c_1_n[k] * np.cos(2 * np.pi * f_1_n[k] * t_sim + theta_1_n[k])

# Compute the autocorrelation function of g1_t_tilde
r_g1_g1 = correlate(g1_t_tilde, g1_t_tilde, mode='full', method='auto') / len(g1_t_tilde)

# Compute the Power Spectral Density (PSD)
PSD_S = np.fft.fft(r_g1_g1)
len_S = len(PSD_S)
f_PSD = (np.arange(-len_S // 2, len_S // 2) / len_S) * fs

# Plot the PSD
plt.plot(f_PSD, np.fft.fftshift(np.abs(PSD_S) / len_S), 'b--')
Omega_p = 2
f = np.arange(-fm, fm + 1)
S_f = Omega_p / (2 * np.pi * fm * np.sqrt(1 - (f / fm)**2))
plt.plot(f, S_f, 'r-')

# Plot the simulation model
f_tilde = np.concatenate([-f_1_n[::-1], f_1_n])
S_mm_tilde = np.concatenate([c_1_n[::-1]**2, c_1_n**2]) / 4
plt.stem(f_tilde, S_mm_tilde, 'm', linefmt='m-', markerfmt='mx', basefmt=' ')

# Configure and show plot
plt.axis([-100, 100, 0, 0.08])
plt.legend(['Simulation', 'Reference Model', 'Simulation Model'])
plt.xlabel('Doppler frequency, f in Hz')
plt.ylabel(r'PSD, $S_{g_1 g_1}(f)$')
plt.grid(True)

# Save the plot
plt.savefig('doppler_frequency_psd.png')

# Show the plot
plt.show()
