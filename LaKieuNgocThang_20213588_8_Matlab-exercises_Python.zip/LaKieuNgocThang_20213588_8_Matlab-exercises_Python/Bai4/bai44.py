import numpy as np
import matplotlib.pyplot as plt
from scipy.special import iv

# Load data from the .npz file
data = np.load('ex4p1_Res.npz')
f1 = data['f1']
f2 = data['f2']
c1 = data['c1']
c2 = data['c2']
th1 = data['th1']
th2 = data['th2']

# Sampling frequency and simulation time
f_s = 50000  # Sampling frequency
T_sim = 20  # Simulation time
t = np.arange(0, T_sim + 1/f_s, 1/f_s)  # Time array

def g(c, f, th, t):
    """
    Generates the deterministic process g(t).
    
    Parameters:
    c (array): Amplitudes of the sinusoids.
    f (array): Frequencies of the sinusoids.
    th (array): Phases of the sinusoids.
    t (array): Time values.
    
    Returns:
    y (array): The generated deterministic process.
    """
    y = np.zeros_like(t)
    for n in range(len(f)):
        y += c[n] * np.cos(2 * np.pi * f[n] * t + th[n])
    return y

# Generate the deterministic processes
g1 = g(c1, f1, th1, t)
g2 = g(c2, f2, th2, t)
g = g1 + 1j * g2  # Combine to form a complex signal
alpha = np.abs(g)  # Amplitude of the signal

# Statistical properties
g_mean = np.mean(g)
g_variance = np.var(g)
g1_mean = np.mean(g1)
g1_variance = np.var(g1)
alpha_mean = np.mean(alpha)
alpha_variance = np.var(alpha)
n = len(alpha)

# Histogram for alpha
x = np.arange(0, 3.1, 0.1)
b, _ = np.histogram(alpha, bins=x, density=True)

plt.figure(1)
plt.plot(x[:-1], b, 'b-', label=r'$p_{\alpha}(x)$')
k = 0
ohm_p = 2
p_alpha = (2 * x * (k + 1) / ohm_p) * np.exp(-k - ((k + 1) * x**2 / ohm_p)) * iv(0, (2 * x * np.sqrt(k * (k + 1) / ohm_p)))
plt.plot(x, p_alpha, 'r', label='Rayleigh distribution (Theory)')
plt.title('The PDF of alpha(x)')
plt.xlabel('x')
plt.ylabel(r'$P_{\alpha}(x)$')
plt.legend()
plt.grid(True)

# Save the first plot
plt.savefig('pdf_alpha.png')

# Histogram for g1
plt.figure(2)
x1 = np.arange(-4, 4.1, 0.1)
c, _ = np.histogram(g1, bins=x1, density=True)
plt.plot(x1[:-1], c, 'b-', label=r'$p_{g1}(x)$')
p = (1 / np.sqrt(2 * np.pi)) * np.exp(-x1**2 / 2)
plt.plot(x1, p, 'r', label='Gaussian distribution (Theory)')
plt.title('The PDF of g1 process')
plt.xlabel('x')
plt.ylabel(r'$P_{g1}(x)$')
plt.legend()
plt.grid(True)

# Save the second plot
plt.savefig('pdf_g1.png')

# Show the plots
plt.show()
