import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import correlate

# Load data from the .npz file
data = np.load('ex4p1_Res.npz')
f1 = data['f1']
f2 = data['f2']
c1 = data['c1']
c2 = data['c2']
th1 = data['th1']
th2 = data['th2']

# Sampling frequency and time settings
f_s = 1000  # Sampling frequency
T_s = 1 / f_s  # Sampling period
I1 = int(10000 * T_s * f_s)  # Start index
I2 = int(20000 * T_s * f_s)  # End index
t = np.arange(I1, I2 + 1) * T_s  # Time array

def g(c, f, th, t):
    """
    Generates the deterministic process g(t).
    
    Parameters:
    c (array): Amplitudes of the sinusoids.
    f (array): Frequencies of the sinusoids.
    th (array): Phases of the sinusoids.
    t (array): Time values.
    
    Returns:
    y (array): The generated deterministic process.
    """
    y = np.zeros_like(t)
    for n in range(len(f)):
        y += c[n] * np.cos(2 * np.pi * f[n] * t + th[n])
    return y

# Generate the deterministic process g1
g1 = g(c1, f1, th1, t)

# Compute the autocorrelation function of g1
phi_g1g1 = correlate(g1, g1, mode='full', method='auto') / len(g1)
midpoint = len(phi_g1g1) // 2
phi_g1g1_select = phi_g1g1[midpoint:midpoint + 81]

# Plotting the autocorrelation function
i = np.arange(1, 82)
x = (i - 1) * T_s

plt.plot(x, phi_g1g1_select)
plt.title('The autocorrelation function ACF of g1')
plt.xlabel(r'$\tau$ in seconds')
plt.ylabel(r'$\phi_{g1g1}(\tau)$')
plt.legend([r'$\phi_{g1g1}(\tau)$ of g1'])
plt.grid(True)

# Save the plot
plt.savefig('acf_g1.png')

# Show the plot
plt.show()

# Save the results in a .npz file
np.savez('ex4p5_Res.npz', phi_g1g1_select=phi_g1g1_select, f_s=f_s, phi_g1g1=phi_g1g1)
