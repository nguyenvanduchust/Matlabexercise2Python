import numpy as np

def g(c, f, th, t):
    """
    Generates the deterministic process g(t).
    
    Parameters:
    c (array): Amplitudes of the sinusoids.
    f (array): Frequencies of the sinusoids.
    th (array): Phases of the sinusoids.
    t (array): Time values.
    
    Returns:
    y (array): The generated deterministic process.
    """
    y = np.zeros_like(t)
    for n in range(len(f)):
        y += c[n] * np.cos(2 * np.pi * f[n] * t + th[n])
    return y
