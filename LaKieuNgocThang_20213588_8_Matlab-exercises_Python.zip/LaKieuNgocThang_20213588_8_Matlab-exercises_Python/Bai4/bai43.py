import numpy as np
import matplotlib.pyplot as plt

# Load data from the .npz file
data = np.load('ex4p1_Res.npz')
f1 = data['f1']
f2 = data['f2']
c1 = data['c1']
c2 = data['c2']
th1 = data['th1']
th2 = data['th2']

# Sampling frequency and simulation time
f_s = 270800  # Sampling frequency
T_sim = 0.4  # Simulation time
t = np.arange(0, T_sim, 1/f_s)  # Time array

def g(c, f, th, t):
    """
    Generates the deterministic process g(t).
    
    Parameters:
    c (array): Amplitudes of the sinusoids.
    f (array): Frequencies of the sinusoids.
    th (array): Phases of the sinusoids.
    t (array): Time values.
    
    Returns:
    y (array): The generated deterministic process.
    """
    y = np.zeros_like(t)
    for n in range(len(f)):
        y += c[n] * np.cos(2 * np.pi * f[n] * t + th[n])
    return y

# Generate the deterministic processes
g1 = g(c1, f1, th1, t)
g2 = g(c2, f2, th2, t)
g = g1 + 1j * g2  # Combine to form a complex signal
alpha = np.abs(g)  # Amplitude of the signal
alpha_dB = 20 * np.log10(alpha)  # Convert amplitude to dB

# Plotting
plt.plot(t, alpha_dB)
plt.title('The channel amplitude in dB')
plt.xlabel('t')
plt.ylabel(r'$\alpha(t)$')
plt.legend([r'$\alpha(t)$ in dB'])
plt.grid(True)

# Save the plot
plt.savefig('channel_amplitude_dB.png')

# Show the plot
plt.show()
