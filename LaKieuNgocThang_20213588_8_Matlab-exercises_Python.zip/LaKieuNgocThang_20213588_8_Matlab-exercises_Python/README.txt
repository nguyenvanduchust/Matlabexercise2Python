To run the scripts in this repository, make sure you have the following Python libraries installed:

1. matplotlib: A plotting library for creating static, animated, and interactive visualizations in Python.
Installation:
	pip install matplotlib


2. numpy: A fundamental package for numerical computing with Python.
Installation:
	pip install numpy
	

3. scipy: A library for scientific and technical computing in Python, providing functions that operate on numerical data.
Installation:
	pip install scipy
	

These libraries are essential for executing the scripts and running the simulations provided.
