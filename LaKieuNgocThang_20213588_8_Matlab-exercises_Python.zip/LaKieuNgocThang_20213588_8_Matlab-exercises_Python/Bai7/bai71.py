import numpy as np
import matplotlib.pyplot as plt

# Function to generate the convolutional code trellis
def poly2trellis(constraint_length, code_generator):
    n = len(code_generator)
    num_states = 2 ** (constraint_length - 1)
    next_state = np.zeros((num_states, 2), dtype=int)
    output = np.zeros((num_states, 2), dtype=int)

    # Generate next state and output for each state and input bit
    for state in range(num_states):
        for bit in range(2):
            shift_register = np.array(list(np.binary_repr(state, width=constraint_length - 1)), dtype=int)
            shift_register = np.append(bit, shift_register)
            next_state[state, bit] = int(''.join(map(str, shift_register[:-1])), 2)
            encoded_bits = [np.bitwise_xor.reduce(shift_register & np.array(list(np.binary_repr(gen, width=constraint_length)), dtype=int)) for gen in code_generator]
            output[state, bit] = int(''.join(map(str, encoded_bits)), 2)

    return next_state, output

# Function to perform convolutional encoding
def convenc(bits, trellis):
    next_state, output = trellis
    state = 0
    encoded_bits = []
    n_output_bits = len(np.binary_repr(output[0, 0]))  # Fixed bit width for binary representation

    # Encode each input bit sequence
    for bit in bits:
        encoded_bits.append(output[state, bit])
        state = next_state[state, bit]

    # Convert encoded bits to array of integers
    encoded_bits = np.array([int(b) for bits in encoded_bits for b in np.binary_repr(bits, width=n_output_bits)], dtype=int)
    return encoded_bits

# Function to perform Viterbi decoding
def viterbi_decode(bits, trellis, tb_depth):
    next_state, output = trellis
    num_states = len(next_state)
    path_metrics = np.full(num_states, np.inf)
    path_metrics[0] = 0
    paths = np.full((num_states, tb_depth + 1), -1)

    n_output_bits = len(np.binary_repr(output[0, 0]))  # Fixed bit width for binary representation

    # Perform Viterbi decoding
    for t in range(0, len(bits), n_output_bits):
        new_metrics = np.full(num_states, np.inf)
        new_paths = np.full((num_states, tb_depth + 1), -1)

        received_bits = bits[t:t + n_output_bits]
        for state in range(num_states):
            for bit in range(2):
                next_s = next_state[state, bit]
                output_bits = [int(b) for b in np.binary_repr(output[state, bit], width=n_output_bits)]
                metric = path_metrics[state] + np.sum(received_bits != output_bits)

                if metric < new_metrics[next_s]:
                    new_metrics[next_s] = metric
                    new_paths[next_s, :-1] = paths[state, 1:]
                    new_paths[next_s, -1] = bit

        path_metrics = new_metrics
        paths = new_paths

    best_path = paths[np.argmin(path_metrics)]
    return best_path[:tb_depth]

# Channel simulation function with convolutional coding and Viterbi decoding
def cha2(SNR_db, S, meg, trellis):
    Es = np.var(S)
    Eb = Es / 2
    N_0 = Eb / 10**(SNR_db / 10)
    N = np.sqrt(N_0 / 2) * (np.random.randn(*S.shape) + 1j * np.random.randn(*S.shape))
    R = S + N

    detected_bits = np.zeros(len(R) * 2, dtype=int)

    # Decode received symbols and compute bit errors
    for i in range(len(R)):
        distances = np.abs(R[i] - np.array([np.exp(1j * np.pi / 4), np.exp(1j * 3 * np.pi / 4), np.exp(1j * 5 * np.pi / 4), np.exp(1j * 7 * np.pi / 4)]))
        detected_symbol = np.argmin(distances)
        detected_bits[2 * i] = detected_symbol // 2
        detected_bits[2 * i + 1] = detected_symbol % 2

    decoded_bits = viterbi_decode(detected_bits, trellis, tb_depth=len(meg))
    decoded_bits = np.array(decoded_bits[:len(meg)], dtype=int)

    bit_errors = np.sum(meg != decoded_bits)
    return bit_errors

# Parameters for convolutional coding and simulation
k = 3
R_c = 1 / 2
meg = np.round(np.random.rand(5000)).astype(int)
conlen = 3
codegen = [0b111, 0b101]
trellis = poly2trellis(conlen, codegen)
x = convenc(meg, trellis)

S = []
# Map encoded bits to QPSK symbols
for i in range(0, len(x) - 1, 2):
    if i + 1 < len(x):
        if x[i] == 0 and x[i + 1] == 0:
            S.append(np.exp(1j * np.pi / 4))
        elif x[i] == 0 and x[i + 1] == 1:
            S.append(np.exp(1j * 3 * np.pi / 4))
        elif x[i] == 1 and x[i + 1] == 1:
            S.append(np.exp(1j * 5 * np.pi / 4))
        elif x[i] == 1 and x[i + 1] == 0:
            S.append(np.exp(1j * 7 * np.pi / 4))
S = np.array(S)

# Simulation SNR values
SNR_db = np.arange(0, 6, 5)
c = np.zeros(len(SNR_db))

# Simulate bit errors for each SNR value
for i in range(len(SNR_db)):
    c[i] = cha2(SNR_db[i], S, meg, trellis)

# Calculate Bit Error Probability (BEP)
BEP = c / len(meg)

# Plot results
plt.semilogy(SNR_db, BEP, '.--', label='P_b with coder')

# Load and plot comparison BEP without coding
data = np.load('ex6p1_Res.npz')
BEP2 = data['BEP']
plt.semilogy(np.arange(0, 9, 2), BEP2, 'r.--', label='P_b without coder')

# Plot labels and title in English
plt.title('The bit error probability')
plt.xlabel('SNR in dB')
plt.ylabel(r'$P_b$')
plt.legend()
plt.grid(True)

# Save the plot as an image file
plt.savefig('QPSK_BEP_with_vs_without_coder.png')

# Display the plot
plt.show()
