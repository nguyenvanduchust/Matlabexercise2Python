import numpy as np
import matplotlib.pyplot as plt
from scipy.special import iv
from scipy.integrate import trapz

# Parameters
k0 = 0
k1 = 3
k2 = 10
R = np.arange(0.0001, 4.51, 0.05)  # Range for R
ohm_p = 1  # Some constant
rau = R / np.sqrt(ohm_p)  # Normalized R

# Average Duration of Fading (ADF) for k=0
k = k0
L_R = np.sqrt(2 * np.pi * (k + 1)) * rau * np.exp(-k - (k + 1) * rau**2) * iv(0, (2 * rau * np.sqrt(k * (k + 1))))
CDF = np.zeros(len(R))
for idx, r in enumerate(np.arange(0, 4.51, 0.05)):
    x = np.linspace(0, r, int(r / 0.05) + 1)
    p = (2 * x * (k + 1) / ohm_p) * np.exp(-k - ((k + 1) * x**2 / ohm_p)) * iv(0, (2 * x * np.sqrt(k * (k + 1) / ohm_p)))
    CDF[idx] = trapz(p, x)
ADF = CDF / L_R
plt.plot(R, ADF, label='k=0')

# ADF for k=3
k = k1
L_R1 = np.sqrt(2 * np.pi * (k + 1)) * rau * np.exp(-k - (k + 1) * rau**2) * iv(0, (2 * rau * np.sqrt(k * (k + 1))))
CDF1 = np.zeros(len(R))
for idx, r in enumerate(np.arange(0, 4.51, 0.05)):
    x = np.linspace(0, r, int(r / 0.05) + 1)
    p = (2 * x * (k + 1) / ohm_p) * np.exp(-k - ((k + 1) * x**2 / ohm_p)) * iv(0, (2 * x * np.sqrt(k * (k + 1) / ohm_p)))
    CDF1[idx] = trapz(p, x)
ADF1 = CDF1 / L_R1
plt.plot(R, ADF1, 'r.', label='k=3')

# ADF for k=10
k = k2
L_R2 = np.sqrt(2 * np.pi * (k + 1)) * rau * np.exp(-k - (k + 1) * rau**2) * iv(0, (2 * rau * np.sqrt(k * (k + 1))))
CDF2 = np.zeros(len(R))
for idx, r in enumerate(np.arange(0, 4.51, 0.05)):
    x = np.linspace(0, r, int(r / 0.05) + 1)
    p = (2 * x * (k + 1) / ohm_p) * np.exp(-k - ((k + 1) * x**2 / ohm_p)) * iv(0, (2 * x * np.sqrt(k * (k + 1) / ohm_p)))
    CDF2[idx] = trapz(p, x)
ADF2 = CDF2 / L_R2
plt.plot(R, ADF2, 'g-.', label='k=10')

# Plotting
plt.axis([0, 2, 0, 3])
plt.title('The average duration of fading (ADF)')
plt.xlabel('R')
plt.ylabel(r'$t(R) * f_m$')
plt.legend()
plt.grid(True)

# Save the plot
plt.savefig('average_duration_of_fading_adf.png')

# Show the plot
plt.show()
