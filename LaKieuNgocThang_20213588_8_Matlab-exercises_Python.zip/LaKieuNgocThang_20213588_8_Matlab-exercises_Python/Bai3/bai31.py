import numpy as np
import matplotlib.pyplot as plt
from scipy.special import iv

# Parameters
k0 = 0
k1 = 3
k2 = 10
R = np.arange(0, 4.55, 0.05)  # Range for R
ohm_p = 1  # Some constant
rau = R / np.sqrt(ohm_p)  # Normalized R

# Level Crossing Rate (LCR) for k=0
k = k0
L_R = np.sqrt(2 * np.pi * (k + 1)) * rau * np.exp(-k - (k + 1) * rau**2) * iv(0, (2 * rau * np.sqrt(k * (k + 1))))
plt.plot(R, L_R, label='k=0')

# Level Crossing Rate (LCR) for k=3
k = k1
L_R1 = np.sqrt(2 * np.pi * (k + 1)) * rau * np.exp(-k - (k + 1) * rau**2) * iv(0, (2 * rau * np.sqrt(k * (k + 1))))
plt.plot(R, L_R1, 'r.', label='k=3')

# Level Crossing Rate (LCR) for k=10
k = k2
L_R2 = np.sqrt(2 * np.pi * (k + 1)) * rau * np.exp(-k - (k + 1) * rau**2) * iv(0, (2 * rau * np.sqrt(k * (k + 1))))
plt.plot(R, L_R2, 'k-.', label='k=10')

# Plotting
plt.title('The Level Crossing Rate (LCR)')
plt.xlabel('R')
plt.ylabel(r'$L_R(R)/f_m$')
plt.legend()
plt.grid(True)

# Save the plot
plt.savefig('level_crossing_rate_lcr.png')

# Show the plot
plt.show()
