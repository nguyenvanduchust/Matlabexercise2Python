import numpy as np
import matplotlib.pyplot as plt
from scipy.special import iv, gamma

k = 2
x = np.arange(0, 3.01, 0.01)
ohm_p = 1

p_elfa = (2 * x * (k + 1) / ohm_p) * np.exp(-k - ((k + 1) * x**2 / ohm_p)) * iv(0, (2 * x * np.sqrt(k * (k + 1) / ohm_p)))
plt.plot(x, p_elfa, label=r'Ham phan bo Rice $p_{\alpha}(x)$ voi k=2')

m = 1.8
p_alpha1 = (2 * m**m * x**(2 * m - 1) / gamma(m) * ohm_p**m) * np.exp(-m * x**2 / ohm_p)
plt.plot(x, p_alpha1, 'k-+', label=r'Ham phan bo Nakagami $p_{\alpha}(x)$ voi m=1.8')

plt.xlabel('x')
plt.ylabel(r'$p_{\alpha}(x)$')
plt.legend()
plt.grid(True)
plt.show()

