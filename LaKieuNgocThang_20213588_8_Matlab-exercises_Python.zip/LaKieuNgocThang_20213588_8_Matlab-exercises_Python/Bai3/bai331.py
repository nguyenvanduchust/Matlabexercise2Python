import numpy as np
import matplotlib.pyplot as plt
from scipy.special import gamma

# Parameters
m1 = 0.5
m2 = 1
m3 = 4
m4 = 20
ohm_p = 1  # Some constant
x = np.arange(0, 3.05, 0.05)  # Range for x

# Nakagami distribution for m=0.5
m = m1
p_alpha1 = (2 * m**m * x**(2 * m - 1) / gamma(m) * ohm_p**m) * np.exp(-m * x**2 / ohm_p)
plt.plot(x, p_alpha1, label='m=0.5')

# Nakagami distribution for m=1
m = m2
p_alpha2 = (2 * m**m * x**(2 * m - 1) / gamma(m) * ohm_p**m) * np.exp(-m * x**2 / ohm_p)
plt.plot(x, p_alpha2, 'kx:', label='m=1')

# Nakagami distribution for m=4
m = m3
p_alpha3 = (2 * m**m * x**(2 * m - 1) / gamma(m) * ohm_p**m) * np.exp(-m * x**2 / ohm_p)
plt.plot(x, p_alpha3, 'k+-', label='m=4')

# Nakagami distribution for m=20
m = m4
p_alpha4 = (2 * m**m * x**(2 * m - 1) / gamma(m) * ohm_p**m) * np.exp(-m * x**2 / ohm_p)
plt.plot(x, p_alpha4, 'k*--', label='m=20')

# Plotting
plt.title(r'Nakagami Distribution $p_{\alpha}(x)$')
plt.xlabel('x')
plt.ylabel(r'$p_{\alpha}(x)$')
plt.legend()
plt.grid(True)

# Save the plot
plt.savefig('nakagami_distribution.png')

# Show the plot
plt.show()
