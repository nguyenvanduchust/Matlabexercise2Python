import numpy as np
import matplotlib.pyplot as plt

# Parameters
f_c = 900e6  # Carrier frequency
c_0 = 3e8  # Speed of light
v = 109.2e3 / 3600  # Velocity in m/s
f_m = v * f_c / c_0  # Maximum Doppler frequency
ohm_p = 2  # Some constant
z = np.arange(-100, 101, 1)  # Frequency range
S_glgl = np.zeros(201)  # Initialize the PSD array

# Calculate the PSD
for i in range(201):
    f = i - 101
    if abs(f) <= f_m:
        S_glgl[i] = (ohm_p / (2 * np.pi * f_m)) / np.sqrt(1 - (f / f_m) ** 2)
    else:
        S_glgl[i] = 0

# Plotting
plt.plot(z, S_glgl)
plt.title('The power spectral density (PSD)')
plt.xlabel('f')
plt.ylabel(r'$S_{glgl}(f)$')
plt.legend([r'$S_{glgl}(f)$'])
plt.grid(True)

# Save the plot
plt.savefig('power_spectral_density_psd.png')

# Show the plot
plt.show()
