import numpy as np
import matplotlib.pyplot as plt
from scipy.special import j0

# Parameters
f_c = 900e6  # Carrier frequency
c_0 = 3e8  # Speed of light
v = 109.2e3 / 3600  # Velocity in m/s
f_m = v * f_c / c_0  # Maximum Doppler frequency
ohm_p = 2  # Some constant
t = np.arange(0, 0.081, 0.001)  # Time range

# Autocorrelation function
phi_glgl = (ohm_p / 2) * j0(2 * np.pi * f_m * t)

# Plotting
plt.plot(t, phi_glgl)
plt.title('The autocorrelation function ACF')
plt.xlabel(r'$\tau$')
plt.ylabel(r'$\phi_{glgl}(\tau)$')
plt.legend([r'$\phi_{glgl}(\tau)$'])
plt.grid(True)

# Save the plot
plt.savefig('autocorrelation_function_acf.png')

# Show the plot
plt.show()

# Zero lag autocorrelation
phi_glgl_0 = (ohm_p / 2) * j0(0)
print(f"phi_glgl_0: {phi_glgl_0}")
