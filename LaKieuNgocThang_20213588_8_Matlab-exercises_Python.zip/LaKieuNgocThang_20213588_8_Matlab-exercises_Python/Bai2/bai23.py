import numpy as np
import matplotlib.pyplot as plt
from scipy.special import iv

# Parameters
k0 = 0
k1 = 3
k2 = 80
x = np.arange(0, 3.01, 0.01)  # Range for x
ohm_p = 1  # Some constant

# Rice distribution for k=0
k = k0
p_elfa = (2 * x * (k + 1) / ohm_p) * np.exp(-k - ((k + 1) * x**2 / ohm_p)) * iv(0, (2 * x * np.sqrt(k * (k + 1) / ohm_p)))
plt.plot(x, p_elfa, label='k=0')

# Rice distribution for k=3
k = k1
p_elfa1 = (2 * x * (k + 1) / ohm_p) * np.exp(-k - ((k + 1) * x**2 / ohm_p)) * iv(0, (2 * x * np.sqrt(k * (k + 1) / ohm_p)))
plt.plot(x, p_elfa1, 'r.', label='k=3')

# Rice distribution for k=80
k = k2
p_elfa2 = (2 * x * (k + 1) / ohm_p) * np.exp(-k - ((k + 1) * x**2 / ohm_p)) * iv(0, (2 * x * np.sqrt(k * (k + 1) / ohm_p)))
plt.plot(x, p_elfa2, 'b-.', label='k=80')

# Plotting
plt.title('Rice Distribution')
plt.xlabel('x')
plt.ylabel(r'$p_{\alpha}(x)$')
plt.legend()
plt.grid(True)

# Save the plot
plt.savefig('rice_distribution.png')

# Show the plot
plt.show()
