import numpy as np
import matplotlib.pyplot as plt

# Parameters for the theoretical Gaussian distribution
m_mu = 0  # Mean
sigma_mu = 1  # Standard deviation
n = 1000000  # Number of samples for the experimental distribution

# Theoretical Gaussian PDF
x = np.arange(-4, 4.05, 0.05)
p = (1 / np.sqrt(2 * np.pi) / sigma_mu) * np.exp(-(x - m_mu) ** 2 / (2 * sigma_mu ** 2))
check = np.trapz(p, x)  # Numerical integration to check the area under the curve

# Plot the theoretical Gaussian PDF
plt.plot(x, p, 'r', label='Theoretical')
plt.title('Gaussian distributed PDF')
plt.xlabel('X')
plt.ylabel('P(X)')

# Experimental data
y = np.random.randn(n)
x2 = np.arange(-4, 4.1, 0.1)
c, bins = np.histogram(y, bins=x2, density=True)
bin_centers = 0.5 * (bins[1:] + bins[:-1])

# Plot the experimental histogram as stems
plt.stem(bin_centers, c, 'b', markerfmt='bo', basefmt=" ", label='Experimental')

# Add legend and save the plot
plt.legend()
plt.savefig('gaussian_pdf_comparison.png')
plt.show()
