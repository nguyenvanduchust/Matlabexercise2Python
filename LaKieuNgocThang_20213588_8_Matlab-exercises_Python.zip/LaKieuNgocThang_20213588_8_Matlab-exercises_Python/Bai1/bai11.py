import numpy as np
import matplotlib.pyplot as plt

# Parameters
t_a = 0.05  # Step size for the range
x = np.arange(-4, 4 + t_a, t_a)  # Range for x

# Gaussian PDF
p = np.exp(-x**2 / 2) / np.sqrt(2 * np.pi)  # Gaussian PDF

# Integration check using trapezoidal rule
check = np.trapz(p, x)  # Numerical integration of the PDF

# Plotting
plt.plot(x, p)  # Plot the Gaussian PDF
plt.title('PDF of a Gaussian distributed random variable', fontsize=12)
plt.xlabel('x', fontsize=12)
plt.ylabel('P(x)', fontsize=12)

# Save the plot
plt.savefig('gaussian_pdf.png')  # Save the plot as a PNG file

# Show the plot
plt.show()  # Display the plot
