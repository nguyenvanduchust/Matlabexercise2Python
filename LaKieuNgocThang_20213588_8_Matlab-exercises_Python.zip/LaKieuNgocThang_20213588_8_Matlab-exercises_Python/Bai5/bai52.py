import numpy as np
import matplotlib.pyplot as plt

# Load data from the .npz file
data = np.load('ex5p1_Res.npz')
S = data['S']

# Calculate signal power and noise parameters
Es = np.var(S)  # Symbol energy
Eb = Es / 2  # Bit energy
SNR_db = 6  # Signal-to-noise ratio in dB
N_0 = Eb / 10**(SNR_db / 10)  # Noise power spectral density
N = np.sqrt(N_0 / 2) * (np.random.randn(*S.shape) + 1j * np.random.randn(*S.shape))  # Noise

# Received signal
R = S + N

# Plot the received signal constellation
plt.plot(R.real, R.imag, '.', label='$S_m$')
plt.plot(S.real, S.imag, 'r*', label='$S$')
t = np.arange(0, 2 * np.pi, 0.01)
plt.plot(np.cos(t), np.sin(t), 'r--')

# Plot settings
plt.legend()
plt.xlabel('I')
plt.ylabel('Q')
plt.title('The complex signal-space diagram of 4-QPSK')
plt.grid(True)

# Save the plot
plt.savefig('qpsk_signal_space_diagram_with_noise.png')

# Show the plot
plt.show()
