import numpy as np
import matplotlib.pyplot as plt

# Generate random binary sequence
x = np.round(np.random.rand(1, 100000))[0]

# QPSK modulation
S = []
for i in range(0, len(x), 2):
    if x[i] == 0 and x[i + 1] == 0:
        S.append(np.exp(1j * np.pi / 4))
    elif x[i] == 0 and x[i + 1] == 1:
        S.append(np.exp(1j * 3 * np.pi / 4))
    elif x[i] == 1 and x[i + 1] == 1:
        S.append(np.exp(1j * 5 * np.pi / 4))
    elif x[i] == 1 and x[i + 1] == 0:
        S.append(np.exp(1j * 7 * np.pi / 4))

S = np.array(S)

# Save the results
np.savez('ex5p1_Res.npz', S=S, x=x)

# Plot the QPSK constellation
plt.plot(S.real, S.imag, '*')
t = np.arange(0, 2 * np.pi, 0.01)
plt.plot(np.cos(t), np.sin(t), 'r--')

plt.xlabel(r'$\phi(t)$')
plt.ylabel(r'$S_m$')
plt.title('The complex signal-space diagram for 4-QPSK')
plt.grid(True)

# Save the plot
plt.savefig('qpsk_signal_space_diagram.png')

# Show the plot
plt.show()
